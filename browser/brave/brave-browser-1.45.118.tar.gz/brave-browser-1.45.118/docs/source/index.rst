.. Copyright (c) 2020 Brave Software

.. _rs_welcome:

Brave browser documentation
---------------------------

This page has now moved to `brave.com/linux <https://brave.com/linux>`_
