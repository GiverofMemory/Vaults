#! /usr/bin/env bash
$XGETTEXT -kaliasLocal *.h *.cpp -o $podir/kfmclient.pot
