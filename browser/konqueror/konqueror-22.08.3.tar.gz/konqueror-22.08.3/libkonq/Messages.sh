#! /usr/bin/env bash
$XGETTEXT src/*.cpp src/*.h -o $podir/libkonq.pot
