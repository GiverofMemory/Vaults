#include "filteropts.h"
#include <KPluginFactory>

K_PLUGIN_CLASS_WITH_JSON(KCMFilter, "khtml_filter.json")

#include "khtml_filter.moc"
