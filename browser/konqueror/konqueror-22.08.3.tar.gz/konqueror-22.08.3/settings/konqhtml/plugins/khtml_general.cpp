#include "generalopts.h"
#include <KPluginFactory>

K_PLUGIN_CLASS_WITH_JSON(KKonqGeneralOptions, "khtml_general.json")

#include "khtml_general.moc"
