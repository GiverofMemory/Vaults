#! /usr/bin/env bash
$XGETTEXT *.cpp -o $podir/kcmkonq.pot
