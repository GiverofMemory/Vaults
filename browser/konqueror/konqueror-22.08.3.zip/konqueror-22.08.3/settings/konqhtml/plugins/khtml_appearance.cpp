#include "appearance.h"
#include <KPluginFactory>

K_PLUGIN_CLASS_WITH_JSON(KAppearanceOptions, "khtml_appearance.json")

#include "khtml_appearance.moc"
