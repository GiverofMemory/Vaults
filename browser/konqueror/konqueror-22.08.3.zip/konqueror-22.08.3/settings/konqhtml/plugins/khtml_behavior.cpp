#include "htmlopts.h"
#include <KPluginFactory>

K_PLUGIN_CLASS_WITH_JSON(KMiscHTMLOptions, "khtml_behavior.json")

#include "khtml_behavior.moc"
