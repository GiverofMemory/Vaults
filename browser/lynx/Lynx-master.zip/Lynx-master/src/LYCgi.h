#ifndef LYCGI_H
#define LYCGI_H

#ifndef HTUTILS_H
#include <HTUtils.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
    extern void add_lynxcgi_environment(const char *variable_name);

#ifdef __cplusplus
}
#endif
#endif				/* LYGETFILE_H */
