#ifndef UCAUTO_H
#define UCAUTO_H

#include <UCDefs.h>

#ifdef __cplusplus
extern "C" {
#endif
    extern void UCChangeTerminalCodepage(int newcs, LYUCcharset *p);

#ifdef __cplusplus
}
#endif
#endif				/* UCAUTO_H */
