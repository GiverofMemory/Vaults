ALTER TABLE history ADD image TEXT;
